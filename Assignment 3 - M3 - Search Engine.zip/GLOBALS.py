FINAL_INDEX = "C:\\1_Repos\\developer\\final_index"

REG_INDEX = "C:\\1_Repos\\developer\\index"